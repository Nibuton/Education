public class Task_1_2 {
    public static void main(String[] args){
        byte a = 10;
        int b = 1000;
        long c = 10000L;
        short d = 100;
        float e = 1000.15f;
        double f = 1003.456;
        boolean g = false;
        char h = 'a';
        String i = "ABC";

        System.out.println(a);
        System.out.println(b);
        System.out.println(c);
        System.out.println(d);
        System.out.println(e);
        System.out.println(f);
        System.out.println(g);
        System.out.println(h);
        System.out.println(i);
    }
}
