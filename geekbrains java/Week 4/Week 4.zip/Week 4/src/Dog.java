public class Dog extends Animal {

    float max_height;
    float max_length_run;
    float max_length_swim;

    public Dog(){
        super();
        max_height = 0.5f;
        max_length_run = 500;
        max_length_swim = 10;
    }

    public Dog(String name, int age, String color, float max_height, float max_length_run, float max_length_swim){
        super(name, age, color);
        this.max_height = max_height;
        this.max_length_run = max_length_run;
        this.max_length_swim = max_length_swim;
    }

    public Dog(String name, int age, String color){
        super(name, age, color);
        max_height = 0.5f;
        max_length_run = 500;
        max_length_swim = 10;
    }

    public void setMax_height(float max_height){
        this.max_height = max_height;
    }

    public void setMax_length_run(float max_length_run){
        this.max_length_run = max_length_run;
    }

    public void setMax_length_swim(float max_length_swim){
        this.max_length_swim = max_length_swim;
    }

    public float getMax_height(){
        return max_height;
    }

    public float getMax_length_run(){
        return max_length_run;
    }

    public float getMax_length_swim(){
        return max_length_swim;
    }

    @Override
    public void Jump(float height) {
        System.out.println((height >= max_height) ? "I can't, too high" : "Dog jumped " + height);
    }


    @Override
    public void Run(float length) {
        System.out.println((length >= max_length_run) ? "I can't, too far" : "Dog ran " + length);
    }

    @Override
    public void Swim(float length) {
        System.out.println((length >= max_length_swim) ? "I can't, too far" : "Dog swam " + length);
    }
}
