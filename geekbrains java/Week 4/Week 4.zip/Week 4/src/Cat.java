public class Cat extends Animal {

    @Override
    public void Jump(float height) {
        System.out.println((height >= 2) ? "I can't, too high" : "Dog jumped " + height);
    }


    @Override
    public void Run(float length) {
        System.out.println((length >= 200) ? "I can't, too far" : "Dog ran " + length);
    }

    @Override
    public void Swim(float length) {
        System.out.println("I can't swim");
    }
}
