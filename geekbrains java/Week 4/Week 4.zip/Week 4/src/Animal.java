public abstract class Animal {

    String name;
    int age;
    String color;

    public Animal(){
        name = "Jane Doe";
        age = 1;
        color = "Unknown";
    }

    public Animal(String name, int age, String color){
        this.name = name;
        this.age = age;
        this.color = color;
    }

    public void getGeneralInfo(){
        System.out.println("Name: " + name + " Age: " + age + " Color: " + color);
    }

    public void setName(String name){
        this.name = name;
    }

    public void setAge(int age){
        this.age = age;
    }

    public void setColor(String color){
        this.color = color;
    }

    public String getName(){
        return name;
    }

    public int getAge(){
        return age;
    }

    public String getColor(){
        return color;
    }

    abstract public void Jump(float height);

    abstract public void Run(float length);

    abstract public void Swim(float length);
}
